﻿using System;
using System.Collections.Generic;

namespace csillag_terkep.Models;

public partial class ConstellationLine
{
    public int Star1 { get; set; }

    public int Star2 { get; set; }
}
